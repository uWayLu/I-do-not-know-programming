<?php
    setcookie("tzoffset", "", time() - 3600);
    echo "<head>\n";
    echo "<meta http-equiv='refresh' content='0;URL=index.php'>\n";
    echo "</head>\n";
?>
