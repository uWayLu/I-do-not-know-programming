<?php
header("Location: timeclock.php");
?>
